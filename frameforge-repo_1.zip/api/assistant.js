// api/assistant.js — proxy IA sécurisé AVEC contrôle du palier côté serveur.
// La clé reste serveur. Le palier n'est PAS décidé par le client : il est plafonné par la base.
// Front (prod) -> POST /api/assistant  body:{ messages, tier, ctx }  + header Authorization: Bearer <token>
import jwt from "jsonwebtoken";
import { query } from "./db.js";

const ORDER = { gratuit: 0, pro: 1, elite: 2 };
const NAME = ["gratuit", "pro", "elite"];

function instructions(tier) {
  if (tier === "elite")
    return " NIVEAU ELITE : expert proactif. Plan d'optimisation personnalisé étape par étape adapté à la config exacte, anticipe les goulots, propose une courbe/undervolt SÛRE, plan d'action complet et structuré.";
  if (tier === "pro")
    return " NIVEAU PRO : réponses détaillées, tous les jeux, réglages BIOS et RAM précis (XMP/EXPO, PBO, timings), comparaisons avant/après.";
  return " NIVEAU GRATUIT : réponses courtes et générales (3-4 phrases). Pour les réglages BIOS détaillés et l'optimisation avancée, invite à passer en Pro (4,99€) ou Elite (9,99€).";
}

async function tierServeur(token) {
  if (!token) return "gratuit";
  try {
    const p = jwt.verify(token, process.env.JWT_SECRET);
    const r = await query(
      `SELECT COALESCE(LOWER(o.nom),'gratuit') AS tier
         FROM utilisateur u
         LEFT JOIN abonnement a ON a.id_utilisateur=u.id_utilisateur AND a.statut='actif'
         LEFT JOIN offre o ON o.id_offre=a.id_offre
        WHERE u.id_utilisateur=$1 ORDER BY o.niveau DESC NULLS LAST LIMIT 1`, [p.id]);
    return r.rows[0] ? r.rows[0].tier : "gratuit";
  } catch (e) { return "gratuit"; }
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", process.env.SITE_URL || "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "content-type, authorization");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Méthode non autorisée" });

  const KEY = process.env.ANTHROPIC_API_KEY;
  if (!KEY) return res.status(500).json({ error: "ANTHROPIC_API_KEY manquante" });

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : (req.body || {});
    const { messages, tier: demande, ctx } = body;
    if (!Array.isArray(messages)) return res.status(400).json({ error: "messages[] requis" });

    // Palier effectif = min(demandé, palier réel en base) -> impossible de tricher côté client
    const h = req.headers.authorization || "";
    const token = h.startsWith("Bearer ") ? h.slice(7) : null;
    const dbTier = await tierServeur(token);
    const eff = NAME[Math.min(ORDER[demande] ?? 0, ORDER[dbTier])];

    const base = "Tu es l'assistant IA de FRAMEFORGE, un outil d'optimisation des FPS pour le jeu compétitif sur PC. "
      + (ctx ? ("Config de l'utilisateur : " + String(ctx).slice(0, 500) + ". ") : "")
      + "Réponds en français, clair et actionnable, sans conseils dangereux (pas d'overvolt extrême). N'invente pas de chiffres de benchmark précis.";
    const system = base + instructions(eff);

    const trimmed = messages.slice(-12).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 4000),
    }));

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 1000, system, messages: trimmed }),
    });
    const data = await r.json();
    return res.status(r.status).json(data);
  } catch (e) {
    return res.status(500).json({ error: "Erreur serveur assistant" });
  }
}
